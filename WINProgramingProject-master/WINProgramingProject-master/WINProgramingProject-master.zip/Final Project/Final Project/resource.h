//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// Resource.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDB_BITMAP1                     102
#define IDB_PLAYER                      102
#define IDB_CIRCLEBOOM                  103
#define IDB_LASERBOOM                   104
#define IDB_BITMAP2                     105
#define IDB_TELEPORT                    105
#define IDB_YOUDIE                      106
#define IDB_HELP                        107
#define IDB_MAIN                        108
#define IDB_SELECTSTAGE                 109
#define IDB_BITMAP3                     110
#define IDB_YOUWIN                      110
#define IDB_PLAYER2                     111
#define IDB_TELEPORT1                   112
#define IDB_TELEPORT2                   112
#define IDB_BITMAP4                     113
#define IDB_SELECTPLAY                  113

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
